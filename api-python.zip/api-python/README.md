# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact

### How to use it? ###

1) Clone this repository with the following command:<br>
git clone git@bitbucket.org:extendeal/api-python.git

2) Create a virtual enviroment<br>

python3 -m venv myenv
source myenv/bin/activate

3) Install the necessary libraries and packages: <br>

pip install -r requirements.txt

4) Access the folder: <br>
cd app/

5) Run the script: <br>

python3 run.py

6) Open in the browser the following link: <br>

http://127.0.0.1:8000

7) Enter authentications credentials: <br>

username: extendeal
password: 123docs