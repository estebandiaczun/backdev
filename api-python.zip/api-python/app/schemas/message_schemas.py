from pydantic import BaseModel

class Response(BaseModel):
    message: str

class Success(Response):
    message: str = "Successful response"

class Error403(Response):
    message: str = "Authorization required"

class Error401(Response):
    message: str = "Wrong username/password, check login information"

class Error422(Response):
    message: str = "Missing parameter in the request body"