from pydantic import BaseSettings

class Settings(BaseSettings):
    JWT_SECRET_KEY: str
    JWT_ALGORITHM: str
    AUTH_USERNAME: str
    AUTH_HASHED_PASSWORD: str
    API_KEY: str

    class Config:
        env_file = "./.env"

settings = Settings()