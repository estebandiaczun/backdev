from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse, Response
from auth.utils import authenticate_user, create_access_token
from schemas.user_schemas import UserCredentials

auth_router = APIRouter()

@auth_router.post("/create_access_token", include_in_schema=False)
async def login_for_access_token(user: UserCredentials, response: Response):

    is_valid = authenticate_user(user.username, user.password)

    if is_valid:
        access_token = create_access_token()
        response = JSONResponse(content={"message": "Login Succesfully", "status":200})
        response.set_cookie(key="access_token", value=access_token)

        return response

    raise HTTPException(status_code=400, detail="The username or password is incorrect")