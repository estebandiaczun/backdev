import os

# Start server

os.system("uvicorn main:app")