import json
from os import remove
from tqdm import tqdm
from time import sleep
from scrapers import login_cofarsur
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import mysql.connector
from mysql.connector import errorcode
QUOTES = chr(39)
TIMEOUT: float = 4
class ScrapedProduct:
    def __init__(self, data) -> None:
        self.product_name: str = data[0]
        self.is_active: str = data[1]
class Product:
    def __init__(self, data) -> None:
        self.product_name: str = data[1]
        self.barcode: str = data[2]
        self.tax_iva = float(data[3])
        self.available: str = data[4]
        self.category: str = data[5]
        self.laboratory: str = data[6]
        self.created_at = str(data[7])
        self.last_update = str(data[8])
def scraper_upload_csv_file(driver, storage_csv_file):
    driver.find_element(By.CSS_SELECTOR, f"li[data-rel={QUOTES}#Operaciones{QUOTES}]").click()
    sleep(TIMEOUT)
    driver.find_element(By.LINK_TEXT, "Importar Pedido").click()
    driver.find_element(By.ID, "import_type").click()
    driver.find_element(By.CSS_SELECTOR, f"option[value={QUOTES}8{QUOTES}]").click()
    driver.find_element(By.CSS_SELECTOR, f"input[type={QUOTES}file{QUOTES}]").send_keys(storage_csv_file)
    template_upload = driver.find_element(By.CLASS_NAME, "template-upload")
    template_upload.find_element(By.TAG_NAME, "button").click()
    sleep(TIMEOUT)
    driver.find_element(By.ID, "submit-import-form").click()
    sleep(TIMEOUT * 2)
def scraper_get_products(driver):
    # Obtener el numero de productos cargados en la pagina web
    table_size_number = driver.execute_script(f"return document.getElementById({QUOTES}thetable{QUOTES}).tBodies[0].rows.length")
    # En modo de desarrollo cambiar el valor de table_size_number por 5 para evitar multiples consultas no necesarias
    # table_size_number = 5
    result = []
    # Recorrer los productos y obtener la informacion del mismo
    for id_value in range(0, table_size_number):
        product_name = driver.execute_script(f"return document.getElementById({QUOTES}factura_new_facturaArticuloes_{id_value}_produc_autocomplete{QUOTES}).value")
        is_active = driver.execute_script(f"return document.getElementById({QUOTES}factura_new_facturaArticuloes_{id_value}_disponible{QUOTES}).value")
        # Validar que el producto tenga nombre
        if product_name:
            scraped_product = ScrapedProduct([product_name, is_active])
            result.append(scraped_product)
    return result
def check_products_with_database(cnx, products):
    cursor = cnx.cursor()
    products_available = []
    products_not_found = []
    print("Buscando los productos en la base de datos:\n")
    for _product in tqdm(products):
        scraped_product: ScrapedProduct = _product
        # Hace la busqueda en la base de datos por el nombre del producto (Agregar order BY)
        try:
            cursor.execute("SELECT * FROM catalogo_cofarsur WHERE product = %s", [scraped_product.product_name])
        except Exception as e:
            print(e)
        result = cursor.fetchone()
        if result:
            # El producto se encontro el la base de datos
            product = Product(data=result)
            # Armar formato a exportar en JSON
            products_available.append({
                "product_name": product.product_name,
                "barcode": product.barcode,
                "tax_iva": product.tax_iva,
                "available": product.available,
                "category": product.category,
                "laboratory": product.laboratory,
                "created_at": product.created_at,
                "last_update": product.last_update
            })
        else:
            # El producto no se encontro en la base de datos
            products_not_found.append({
                "product_name": scraped_product.product_name,
                "is_active": scraped_product.is_active
            })
    cursor.close()
    return {"products_available": products_available, "products_not_found": products_not_found}
def start_scraper(settings, storage_csv_file) -> list:
    pass
def main(settings, storage_csv_file: str):
    try:
        cnx = mysql.connector.connect(user=settings.DB_USER, password=settings.DB_PASSWORD, host=settings.DB_HOST, port=settings.DB_PORT, database=settings.DB_DATABASE)
    except mysql.connector.Error as error:
        if error.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            raise Exception("Something is wrong with your user name or password")
        elif error.errno == errorcode.ER_BAD_DB_ERROR:
            raise Exception("Database does not exist")
        else:
            raise Exception(error)
    # Iniciar el scraper
    products = start_scraper(settings, storage_csv_file)
    # Valido los productos obtenidos de la pagina web con los de la base de datos
    products_check = check_products_with_database(cnx=cnx, products=products)
    # Finalizar
    remove(storage_csv_file)
    cnx.close()
    return products_check