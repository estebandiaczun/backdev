import json
import logging
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s : %(levelname)s : %(message)s',
                    filename = 'logs_scrapers.log',
                    filemode = 'w',)
def init_login(username: str, password: str):
    logging.info('Comienza el programa')
    if not username or not password:
        response_payload = {
            "status_code": 422,
            "message": "Missing parameter in the request body"
            }
        logging.error('Falto un parametro en el body')
        return json.dumps(response_payload)
    chrome_options = Options()
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    try:
        driver = webdriver.Chrome(options=chrome_options)
        driver.get("https://www.cofarsur.net/inicio/")
        logging.info('Se abrio la pagina cofarsur')
        driver.find_element("xpath", '//*[@id="signin_username"]').send_keys(username)
        driver.find_element("xpath", '//*[@id="signin_password"]').send_keys(password)
        driver.find_element("xpath", '/html/body/header/div/div/div[2]/form/button').click()

        logout_element = driver.find_element("xpath", '//*[@id="user-nav"]/div/span[2]')
        if logout_element:
            response_payload = {
                "status_code": 200,
                "message": "Login OK"
            }
            logging.info('Se pudo hacer login!')
            return json.dumps(response_payload)

            #Puede o NO aparecer un pop up, si lo encuentra lo cierra y sino sigue
        try:
            driver.find_element("xpath", '//*[@id="notificacion1247880"]/div/div[1]').click()
            logging.info('Se cerro el popup')
            logging.warning('Puede aparecer otro popup con otro path')
        except:
            pass
            logging.info('No se contro ningun popup, todo bien')
            
    except Exception as e:
        print(e)
        response_payload = {
            "status_code": 401,
            "message": "Wrong username/password, check login information"
        }
        logging.error('No se pudo hacer login, username o password incorrectos')
        return json.dumps(response_payload)
    except KeyboardInterrupt:
        logging.error('Fue interrumpido por el usuario')
    driver.quit()