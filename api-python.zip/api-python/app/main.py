from fastapi import FastAPI, Depends, Body, UploadFile, File, HTTPException, status
from fastapi.openapi.docs import get_swagger_ui_html
from os import getcwd, path
from fastapi.responses import JSONResponse, FileResponse
from dotenv import load_dotenv
from auth.auth_router import auth_router
from auth.utils import verify_access_token, verify_api_key
import json
from scrapers.login_cofarsur import init_login
from schemas.message_schemas import *

load_dotenv()

app = FastAPI(docs_url=None, redoc_url=None)

app.include_router(auth_router)

@app.get("/", include_in_schema=False)
async def root():
    return FileResponse("auth/template/authentication_user.html")

@app.get("/auth/template/{file_path:path}", include_in_schema=False)
async def serve_static_files(file_path: str):
    return FileResponse(f"auth/template/{file_path}")


@app.get("/docs", include_in_schema=False, dependencies=[Depends(verify_access_token)])
async def show_docs():
    return get_swagger_ui_html(openapi_url=app.openapi_url, title=app.title + " - Swagger UI")

with open('openapi.json', 'r') as f:
    config = json.load(f)


class Configuration_constructor:
    app.version = config["info"]["version"]
    app.title = config["info"]["title"]
    app.description = config["info"]["description"]
    app.contact = config["info"]["contact"]


@app.post("/login/cofarsur", tags=["Login"], responses={
    200: {"description": "Login OK", "model": Success},
    401: {"description": "Invalid username or password", "model": Error401},
    403: {"description": "Unauthorized access to the API. Check API KEY", "model": Error403},
    422: {"description": "Syntax error in the request body", "model": Error422}
}, )

async def login_validation_for_cofarsur(
    username: str = Body(..., description="Username for website login"),
    password: str = Body(..., description="Password for website login"),
    api_key: str = Depends(verify_api_key)
):
    response = init_login(username, password)
    response = json.loads(response)
    return JSONResponse(content=json.loads(response["body"])["message"], status_code=response["statusCode"])


@app.post("/prices_request/cofarsur", tags=["Prices Requests"], responses={
    200: {"description": "Prices Information response", "model": Success},
    401: {"description": "Invalid username or password", "model": Error401},
    403: {"description": "Unauthorized access to the API. Check API KEY", "model": Error403},
    422: {"description": "Syntax error in the request body", "model": Error422}
}, )
async def price_request_for_cofarsur(
    username: str = Body(..., description="Username for website login"),
    password: str = Body(..., description="Password for website login"),
    csv_file: UploadFile = File(),
    api_key: str = Depends(verify_api_key)
):
    if not csv_file:
        return HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Para continuar se requiere subir un archivo de tipo CSV")

    if csv_file.content_type not in ["text/csv"]:

        return HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="El formato del archivo subido no corresponde al tipo CSV")

    # Guardo el archivo CSV en la carpeta logs

    storage_csv_file = path.join(getcwd(), "logs", "default_file.csv")
    with open(storage_csv_file, 'wb') as f:
        csv_content = await csv_file.read()
        f.write(csv_content)
        f.close()

    # Inicio el scraper
    pass



@app.post("/purchases/cofarsur", tags=["Purchases"], responses={
    200: {"description": "Prices Information response", "model": Success},
    401: {"description": "Invalid username or password", "model": Error401},
    403: {"description": "Unauthorized access to the API. Check API KEY", "model": Error403},
    422: {"description": "Syntax error in the request body", "model": Error422}
}, )
async def purchases_for_cofarsur(
    username: str = Body(..., description="Username for website login"),
    password: str = Body(..., description="Password for website login"),
    api_key: str = Depends(verify_api_key)
):
    response = init_login(username, password)
    pass