import time, os, csv
from tqdm import tqdm
import datetime
from datetime import date
from pathlib import Path

from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

import mysql.connector
from dotenv import load_dotenv
load_dotenv()
today=datetime.date.today() #Fecha de hoy

chrome_options=webdriver.ChromeOptions()
chrome_options.add_argument('--no-sandbox')
#chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-dev-shm-usage')
chrome_options.add_argument('--disable-blink-features=AutomationControlled')
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option('useAutomationExtension', False)

driver=webdriver.Chrome(ChromeDriverManager().install(), chrome_options=chrome_options) 

def does_login():
    try:
        url=driver.get("https://www.cofarsur.net/inicio/")
        driver.find_element(By.CSS_SELECTOR, "#signin_username").send_keys('sierra1')
        driver.find_element(By.CSS_SELECTOR, "#signin_username").send_keys('rivadavia')
        
        driver.find_element("xpath", '/html/body/header/div/div/div[2]/form/button').click()
        time.sleep(10)

        logout_element = driver.find_element("xpath", '//*[@id="user-nav"]/div/span[2]')
        if logout_element:
            print('login ok')
        else:
            print('no se pudo')
            driver.quit()

        #Puede o no aparecer un pop up, si lo encuentra lo cierra y sino sigue
        try:
            driver.find_element("xpath", '//*[@id="notificacion1247880"]/div/div[1]').click()
        except:
            pass

        return does_login
    except:
        url=None
        driver.quit()
does_login()
