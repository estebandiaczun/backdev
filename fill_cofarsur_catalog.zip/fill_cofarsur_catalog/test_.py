from selenium import webdriver
import time
import os
from webdriver_manager.chrome import ChromeDriverManager
from os import path, getcwd
import csv
import mysql.connector
from uuid import uuid4
from tqdm import tqdm
from datetime import date
from random import randint
from dotenv import load_dotenv
load_dotenv()


def is_float(n):
    try:
        return float(n)
    except ValueError:
        return float(0.00)
def is_int(n):
    try:
        return int(n)
    except ValueError:
        return 0
def csv_to_rds():
    con=mysql.connector.connect(
        host="localhost",
        user="root",
        password='esteban!'
    )
    
    #PORT="3306"
    
    #REGION="us-west-2c"
    #DBNAME="extendeal_scrapers"
    PASS='esteban!'

    cwd=os.getcwd() #Guardo el direcctorio actual
    #Creo la carpeta donde se va a guardar el listado
    try:
        os.mkdir(cwd+"\Logs")
    except FileExistsError:
        print("La carpeta Logs ya existe")
    file_destination=cwd+"\Logs\Cofarsur.csv"
 
    cur = con.cursor()
    
    cur.execute("use extendeal_scrapers;")

    with open(file_destination, encoding="utf8") as f:
        csv_reader = csv.DictReader(f, delimiter=",")
        for row in tqdm(csv_reader):
            query="INSERT INTO catalogo_cofarsur(product, codbar, iva, exist, category, laboratory, created_at, updated_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s);"
            cur.execute(query, (row["Producto"], row["Cod.Barra"], is_float(row["T.Iva"]), row["Exist."], row["Rubro"], row["Laboratorio"], str(date.today()), str(date.today())))
            #cur.execute("INSERT INTO catalogo_cofarsur(product, codbar, iva, exist, category, laboratory, created_at, updated_at) VALUES ('" + row["Producto"] + "','" + row["Cod.Barra"] + "'," + (row["T.Iva"]) + ",'" + row["Exist."] + "','" + row["Rubro"] + "','" + row["Laboratorio"] + "','" + (str(date.today())) + "','" + (str(date.today()) + "');"))
            con.commit()

    cur.close()
    return csv_to_rds
csv_to_rds()
