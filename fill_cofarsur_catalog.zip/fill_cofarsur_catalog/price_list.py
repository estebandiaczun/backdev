import time, os, csv
from tqdm import tqdm
import datetime
from datetime import date
from pathlib import Path

from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

import mysql.connector
from dotenv import load_dotenv
load_dotenv()
today=datetime.date.today() #Fecha de hoy
def is_float(n):
    try:
        return float(n)
    except ValueError:
        return float(0.00)

def create_save_folder():
    global driver
    global cwd
    global file_destination

    cwd=Path.cwd() #Guardo el direcctorio actual
    #Creo la carpeta donde se va a guardar el listado
    try:
        path=Path(cwd, "Logs")
    except FileExistsError:
        print("La carpeta Logs ya existe")
    path=Path(cwd, "Logs")
    file_destination=(str(path))

    chrome_options=webdriver.ChromeOptions()
    #chrome_options.add_argument('--no-sandbox')
    #chrome_options.add_argument('--headless')
    #chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_experimental_option("prefs", {
    "download.default_directory": file_destination,
    })
    driver=webdriver.Chrome(ChromeDriverManager().install(), chrome_options=chrome_options) 
create_save_folder()

    # Inicia el scraper 

def does_login():
    try:
        url=driver.get("https://www.cofarsur.net/inicio/")
        time.sleep(1)
        driver.maximize_window()
        driver.find_element("xpath", '//*[@id="signin_username"]').send_keys((os.getenv('LOGIN_USERNAME')))
        time.sleep(1)
        driver.find_element("xpath", '//*[@id="signin_password"]').send_keys(os.getenv('LOGIN_PASSWORD'))
        time.sleep(2)
        driver.find_element("xpath", '/html/body/header/div/div/div[2]/form/button').click()
        time.sleep(10)
        #Puede o no aparecer un pop up, si lo encuentra lo cierra y sino sigue
        try:
            driver.find_element("xpath", '//*[@id="notificacion1247880"]/div/div[1]').click()
        except:
            pass
        return does_login
    except:
        url=None
        driver.quit()
does_login()

def download_price_list():
    time.sleep(2)
    driver.find_element("xpath", '//*[@id="cf-sidebar"]/ul/li[2]/i').click()
    time.sleep(2)
    driver.find_element("xpath", '//*[@id="accordion_Consultas"]/a[4]').click()
    time.sleep(5)
    driver.find_element("xpath", '//*[@id="sumbit_form"]').click()
    time.sleep(40)
    driver.find_element("xpath", '//*[@id="table_products_wrapper"]/div[1]/button[2]').click()
    time.sleep(40)
    return download_price_list
download_price_list()

def change_filename():
    file_oldname=Path(file_destination, "Cofarsur.csv")
    file_newname_newfile=Path(file_destination, (str(today))+'.csv')
    os.rename(file_oldname, file_newname_newfile)
change_filename()

def to_rds():
    ENDPOINT=os.getenv('endpoint')
    PORT=os.getenv('port')
    USER=os.getenv('user')
    REGION=os.getenv('region')
    DBNAME=os.getenv('dbname')
    PASS=os.getenv('pass')
    try:
        conn=mysql.connector.connect(host=ENDPOINT, user=USER, passwd=PASS, port=PORT, database=DBNAME)    
        cur=conn.cursor()

        # Se deja fuera la consulta SELECT para testing
        
        #cur.execute("SELECT * FROM catalogo_cofarsur;")
        #print(cur.fetchall())
        #conn.commit()

        cur.execute('TRUNCATE TABLE catalogo_cofarsur;')
        conn.commit()

        time.sleep(2)

        #Lee el csv e inserta fila por fila en los campos solicitados
        with open(file_destination + (str(today))+'.csv', encoding="utf8") as f:
            csv_reader=csv.DictReader(f, delimiter=",")
            for row in tqdm(csv_reader):
                query="INSERT INTO catalogo_cofarsur(product, codbar, iva, exist, category, laboratory, created_at, updated_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s);"
                cur.execute(query, (row["Producto"], row["Cod.Barra"], is_float(row["T.Iva"]), row["Exist."], row["Rubro"], row["Laboratorio"], str(date.today()), str(date.today())))
                conn.commit()

        cur.close()
        conn.close()
        return to_rds
    except:
        cur==NameError

to_rds()











